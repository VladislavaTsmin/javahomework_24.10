import java.util.Random;
import java.util.Scanner;

//Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
// Программа генерирует два целых однозначных числа.
// Программа задаёт вопрос: результат умножения первого числа на второе?
// Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
// Если пользователь ответил неправильно, то программа должна показать правильный ответ.
public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int num1 = rnd.nextInt(1, 11);
        int num2 = rnd.nextInt(1, 11);
        System.out.println(num1);
        System.out.println(num2);

        int rez = num1 * num2;
        Scanner scn = new Scanner(System.in);
        System.out.println("Ведите результат умножения первого числа на второе: ");
        int userRez = scn.nextInt();
        if(rez == userRez){
            System.out.println("Вы ответили правильно!");
        }else{
            System.out.println("Вы ответили не правильно! Правильный ответ: " + rez);
        }


    }
}