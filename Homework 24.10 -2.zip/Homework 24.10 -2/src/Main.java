import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

//Напишите консольную игру «Камень, ножницы, бумага».
// Пользователь вводит свой выбор (в виде строки или числа).
// Программа случайным образом делает свой выбор и выводит на экран.
// Далее программа показывает, кто победитель – пользователь или программа.
public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Print your choice:" +  Arrays.toString(game.values()));
        String user = scn.nextLine();
        game userChoice = game.valueOf(user.toUpperCase(Locale.ROOT));
        Random rnd = new Random();
        int computerChoice = rnd.nextInt(game.values().length);
        game comp = game.values()[computerChoice];
        System.out.println("Вы выбрали: " + userChoice);
        System.out.println("Компьютер выбрал: " + comp);
        if (userChoice.equals(comp)){
            System.out.println("Ничья");
        }else if (
            userChoice == game.SCISSORS && comp == game.PAPER
            || userChoice == game.STONE && comp == game.SCISSORS
            || userChoice == game.PAPER && comp == game.STONE){
            System.out.println("Вы выйграли");
        }else {
            System.out.println("Вы проиграли");
        }





    }
}