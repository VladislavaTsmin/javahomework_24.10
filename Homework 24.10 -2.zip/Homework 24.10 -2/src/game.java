public enum game{
    STONE,
    PAPER,
    SCISSORS
}
